package com.cg.paymentwallet.service;

import java.math.BigDecimal;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.cg.paymentwallet.beans.Customer;
import com.cg.paymentwallet.beans.Transaction;
import com.cg.paymentwallet.repo.IWalletRepo;

@Service("walletservice")


public class WalletServiceImpl implements IWalletService{

	@Autowired
	private IWalletRepo repo;
	
	


	public void addCustomer(Customer customer) {
		
		repo.save(customer);
	}

	@Override
	public BigDecimal showBalance(String mobileno) {
	Customer customer = repo.findOne(mobileno);
	return customer.getWallet().getBalance();
	}

	@Override
	@ModelAttribute("Transaction")
	public String deposit(String mobileno, String password, BigDecimal amount) {
		String result= null;
		Customer customer = repo.findOne(mobileno);
		if(password.equals(customer.getPassword())) {
			customer.getWallet().setBalance(customer.getWallet().getBalance().add(amount));
			Transaction transaction = new Transaction();
		    transaction.setType("credited");
		    transaction.setAmount(amount);
		    transaction.setBalance(customer.getWallet().getBalance());
		    java.util.Date today = new java.util.Date();
			transaction.setDateOfTrans( new java.sql.Timestamp(today.getTime()));
			transaction.setCustomer(customer);
			customer.addTransaction(transaction);
			repo.save(customer);
			result="Deposited Succesfully and your current balance is :" + customer.getWallet().getBalance();
			
		}
		return result;
	}

	@Override
	public Customer showCustomer(String mobileno) {
		return repo.findOne(mobileno);
	}

	@Override
	@ModelAttribute("Transaction")
	public String withdraw(String mobileno, String password, BigDecimal amount) {
		String result= null;
		Customer customer = repo.findOne(mobileno);
		if(password.equals(customer.getPassword()) && customer.getWallet().getBalance().compareTo(amount)>=0) {
			customer.getWallet().setBalance(customer.getWallet().getBalance().subtract(amount));
			Transaction transaction = new Transaction();
		    transaction.setType("debited");
		    transaction.setAmount(amount);
		    transaction.setBalance(customer.getWallet().getBalance());
		    java.util.Date today = new java.util.Date();
			transaction.setDateOfTrans( new java.sql.Timestamp(today.getTime()));
			transaction.setCustomer(customer);
			customer.addTransaction(transaction);
			repo.save(customer);
			result="Withdrawn Succesfully and your current balance is :" + customer.getWallet().getBalance();
		}
		return result;
	}

	@Override
	public String fundtransfer(String targetmobileno, String sourcemobileno, String password, BigDecimal amount) {
		String result=null;
		if(repo.findOne(targetmobileno)!=null)
		{
			Customer source = repo.findOne(sourcemobileno);
			if(source!=null&& withdraw(sourcemobileno, password, amount)!=null) {
				deposit(targetmobileno, repo.findOne(targetmobileno).getPassword(), amount);
				result="Transferred Succesfully and your current balance is :" + source.getWallet().getBalance();
			}
		}
		return result;
	}

	@Override
	public Set<Transaction> printTransactions(String mobileno, String password) {
		Customer customer = repo.findOne(mobileno);
		if(password.equals(customer.getPassword())) {
			return customer.getTransactions();
		}
		return null;
	}
	
}
